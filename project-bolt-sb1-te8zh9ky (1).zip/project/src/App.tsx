import React from 'react';
import { LoginActivityCard } from './components/LoginActivityCard';
import { DevicesCard } from './components/DevicesCard';
import { Shield } from 'lucide-react';
import type { LoginActivity, Device } from './types';

// Mock data
const mockLoginActivities: LoginActivity[] = [
  {
    id: '1',
    timestamp: new Date().toISOString(),
    username: 'admin@system.com',
    ipAddress: '192.168.1.100',
    status: 'success',
    location: 'New York, US',
  },
  {
    id: '2',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    username: 'unknown@attacker.com',
    ipAddress: '45.33.22.11',
    status: 'failed',
    location: 'Unknown',
  },
  {
    id: '3',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    username: 'developer@system.com',
    ipAddress: '192.168.1.105',
    status: 'success',
    location: 'San Francisco, US',
  }
];

const mockDevices: Device[] = [
  {
    id: '1',
    name: 'Main Server',
    type: 'server',
    status: 'active',
    lastSeen: new Date().toISOString(),
    ipAddress: '10.0.0.1',
  },
  {
    id: '2',
    name: 'Developer Laptop',
    type: 'laptop',
    status: 'compromised',
    lastSeen: new Date().toISOString(),
    ipAddress: '192.168.1.50',
  },
  {
    id: '3',
    name: 'Mobile Device',
    type: 'mobile',
    status: 'active',
    lastSeen: new Date().toISOString(),
    ipAddress: '192.168.1.75',
  }
];

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Shield className="w-8 h-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">
                Security Dashboard
              </span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <LoginActivityCard activities={mockLoginActivities} />
          <DevicesCard devices={mockDevices} />
        </div>
      </main>
    </div>
  );
}

export default App;