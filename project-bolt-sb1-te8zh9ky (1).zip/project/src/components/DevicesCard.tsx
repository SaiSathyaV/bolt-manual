import React from 'react';
import { DashboardCard } from './DashboardCard';
import { Device } from '../types';
import { Laptop, Smartphone, Server, AlertTriangle } from 'lucide-react';

interface DevicesCardProps {
  devices: Device[];
}

export const DevicesCard: React.FC<DevicesCardProps> = ({ devices }) => {
  const getDeviceIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'laptop':
        return <Laptop className="w-5 h-5" />;
      case 'mobile':
        return <Smartphone className="w-5 h-5" />;
      case 'server':
        return <Server className="w-5 h-5" />;
      default:
        return <Laptop className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'compromised':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <DashboardCard title="Devices">
      <div className="grid gap-4">
        {devices.map((device) => (
          <div
            key={device.id}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-4">
              {getDeviceIcon(device.type)}
              <div>
                <p className="font-medium">{device.name}</p>
                <p className="text-sm text-gray-500">{device.ipAddress}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {device.status === 'compromised' && (
                <AlertTriangle className="w-5 h-5 text-red-500" />
              )}
              <span
                className={`px-3 py-1 rounded-full text-sm ${getStatusColor(
                  device.status
                )}`}
              >
                {device.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};