import React from 'react';
import { DashboardCard } from './DashboardCard';
import { LoginActivity } from '../types';
import { format } from 'date-fns';
import { Shield, ShieldAlert } from 'lucide-react';

interface LoginActivityCardProps {
  activities: LoginActivity[];
}

export const LoginActivityCard: React.FC<LoginActivityCardProps> = ({ activities }) => {
  return (
    <DashboardCard title="Login Activity">
      <div className="space-y-4">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-3">
              {activity.status === 'success' ? (
                <Shield className="w-5 h-5 text-green-500" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-red-500" />
              )}
              <div>
                <p className="font-medium">{activity.username}</p>
                <p className="text-sm text-gray-500">{activity.ipAddress}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">
                {format(new Date(activity.timestamp), 'MMM d, yyyy HH:mm')}
              </p>
              <p className="text-sm text-gray-500">{activity.location}</p>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};