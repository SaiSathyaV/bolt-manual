export interface LoginActivity {
  id: string;
  timestamp: string;
  username: string;
  ipAddress: string;
  status: 'success' | 'failed';
  location: string;
}

export interface Device {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'inactive' | 'compromised';
  lastSeen: string;
  ipAddress: string;
}