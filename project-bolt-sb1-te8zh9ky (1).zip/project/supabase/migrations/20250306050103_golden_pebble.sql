/*
  # Security Dashboard Schema

  1. New Tables
    - `login_activities`
      - Tracks user login attempts and their details
    - `devices`
      - Stores information about registered devices
    - `honeypots`
      - Manages honeypot configurations and status
    - `dl_outputs`
      - Stores machine learning model predictions
    - `suricata_rules`
      - Contains IDS/IPS rules
    - `connection_reports`
      - Logs network connection attempts

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated access
*/

-- Login Activities Table
CREATE TABLE IF NOT EXISTS login_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now(),
  username text NOT NULL,
  ip_address text NOT NULL,
  status text NOT NULL,
  location text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE login_activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON login_activities
  FOR SELECT
  TO authenticated
  USING (true);

-- Devices Table
CREATE TABLE IF NOT EXISTS devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  status text NOT NULL,
  last_seen timestamptz DEFAULT now(),
  ip_address text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE devices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON devices
  FOR SELECT
  TO authenticated
  USING (true);

-- Honeypots Table
CREATE TABLE IF NOT EXISTS honeypots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status text NOT NULL,
  attacks_detected integer DEFAULT 0,
  last_attack timestamptz,
  location text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON honeypots
  FOR SELECT
  TO authenticated
  USING (true);

-- DL Outputs Table
CREATE TABLE IF NOT EXISTS dl_outputs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now(),
  model text NOT NULL,
  prediction text NOT NULL,
  confidence numeric NOT NULL,
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dl_outputs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON dl_outputs
  FOR SELECT
  TO authenticated
  USING (true);

-- Suricata Rules Table
CREATE TABLE IF NOT EXISTS suricata_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  severity text NOT NULL,
  category text NOT NULL,
  enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE suricata_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON suricata_rules
  FOR SELECT
  TO authenticated
  USING (true);

-- Connection Reports Table
CREATE TABLE IF NOT EXISTS connection_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now(),
  source_ip text NOT NULL,
  destination_ip text NOT NULL,
  protocol text NOT NULL,
  port integer NOT NULL,
  status text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE connection_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated read access"
  ON connection_reports
  FOR SELECT
  TO authenticated
  USING (true);